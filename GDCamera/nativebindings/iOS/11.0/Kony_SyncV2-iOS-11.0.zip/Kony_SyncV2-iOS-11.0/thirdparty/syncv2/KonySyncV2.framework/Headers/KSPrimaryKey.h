//
//  PrimaryKey.h
//  KonySyncV2
//
//  Created by Harshini Bonam on 09/11/16.
//  Copyright © 2016 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "OrderedDictionary.h"
#import "KSObjectAttribute.h"
/*
 * @name Primary key for a generic object.
 
 */

@interface KSPrimaryKey : NSObject

@property (nonatomic) NSOrderedSet<NSValue *> *attributes;

- (instancetype) init __attribute__((unavailable("Must use initWithKeyArray: instead.")));

- (instancetype)initWithKeyArray:(NSArray <NSString *> *)keyStringArray
                      attributes:(OrderedDictionary *)attributes;

/**
 Returns a set of primary key strings.

 @return Set of primary key strings.
 */
- (NSSet <NSString *> *)getPrimaryKeyStringSet;

@end
