//
//  SDKObjectSync.h
//  KonySyncV2
//
//  Created by Chirag Mantri on 15/02/17.
//  Copyright © 2017 Kony. All rights reserved.
//
#import <Foundation/Foundation.h>

#import "KSConstants.h"

@interface SDKObjectSync : NSObject

/**
 Preventing object creation for SDKObjectSync using init.
 */
- (instancetype)init __attribute__((unavailable("Use initWithName.")));

/**
 Initializing SDKObjectSync
 
 @param name Contains the name of the SDKObject
 @param error NSError object to be propagated in case of error
 @return Instance type of SDKObjectSync
 */
- (instancetype)initWithName:(NSString *)name
                       error:(NSError **)error;


/**
 Method to Start Object Level Sync
 
 @param options contains sync options.
 @param onSuccess callback to be invoked on the Success of SyncSetup.
 @param onFailure callback to be invoked at the time of any error.
 @param onProgress callback to be invoked during sync.
 */
- (void)startSync:(NSDictionary <NSString *,id>*) options
        onSuccess:(KNYSuccessCompletionHandler)onSuccess
        onFailure:(KNYFailureCompletionHandler)onFailure
        onProgress:(KNYProgressCompletionHandler) onProgress;


/**
 * Create method provides ability to create record in local database
 * @param record - list of fields to be populated in record during creation
 * @param options - parameter for future extensibility. MarkforUpload parameter should come through this data structure
 * @param onSuccess callback to be invoked on the Success of record creation.
 * @param onFailure callback to be invoked at the time of any error.
 */

- (void)create:(NSDictionary <NSString *,id>*) record
		options:(NSDictionary <NSString *,id>*)options
		onSuccess:(KNYSuccessCompletionHandler)onSuccess
        onFailure:(KNYFailureCompletionHandler)onFailure;

/**
 * Update method provides ability to update record in local database
 * @param record - list of fields to be updated
 * @param options - Options contains MarkforUpload, Primary Key of object
 * @param onSuccess callback to be invoked on the Success of update operation.
 * @param onFailure callback to be invoked at the time of any error.
 */
- (void)updateByPK:(NSDictionary <NSString *,id>*) record
		options:(NSDictionary <NSString *,id>*)options
		onSuccess:(KNYSuccessCompletionHandler)onSuccess
        onFailure:(KNYFailureCompletionHandler)onFailure;

/**
 * Delete method provides ability to Delete record from local Database
 * @param options - Primary key of record, markforUpload
 * @param onSuccess callback to be invoked on the Success of delete operation.
 * @param onFailure callback to be invoked at the time of any error.
 */
- (void)deleteByPK:(NSDictionary <NSString *,id>*) options		
		onSuccess:(KNYSuccessCompletionHandler)onSuccess
        onFailure:(KNYFailureCompletionHandler)onFailure;

/**
 * Get method provides ability to fetch records from local database
 * @param options - Where clause, OrderBy map, Limit, Offset
 * @param onSuccess callback to be invoked on the Success of get operation.
 * @param onFailure callback to be invoked at the time of any error.
 */
- (void)get:(NSDictionary <NSString *,id>*) options		
		onSuccess:(KNYSuccessCompletionHandler)onSuccess
        onFailure:(KNYFailureCompletionHandler)onFailure;

/**
 * Rollback an object to its previous sync state
 * @param primaryKeyValueMap of record only for which rollback should happen.
 * @param onSuccess onSuccess will be invoked on the Successfull rollback on object.
 * @param onFailure onFailure will be invoked if rollback failed on object.
 */
- (void)rollback:(NSDictionary *)primaryKeyValueMap
       onSuccess:(KNYSuccessCompletionHandler)onSuccess
       onFailure:(KNYFailureCompletionHandler)onFailure;


@end
