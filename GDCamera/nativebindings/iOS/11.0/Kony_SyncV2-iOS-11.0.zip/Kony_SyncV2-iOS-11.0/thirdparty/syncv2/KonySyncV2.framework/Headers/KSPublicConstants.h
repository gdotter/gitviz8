//
//  Header.h
//  KonySyncV2
//
//  Created by Satya Eedara on 07/11/17.
//  Copyright © 2017 Kony. All rights reserved.
//  Defines constants that are exposed to end user through offline objects API input and response objects.
//

#import <Foundation/Foundation.h>

// Constants for SYNC ERROR propagation
#define OBJECT @"object"
#define ERRMSG @"errmsg"
#define OPSTATUS @"opstatus"
#define CALLSTACK @"callStack"
#define SYNC_ERRORS @"syncErrors"
#define OBJECT_SERVICE @"objectService"
#define UPLOAD_BATCH_SIZE @"uploadBatchSize"
#define DOWNLOAD_BATCH_SIZE @"downloadBatchSize"
#define DEVICE_DB_ENCRYPTION_KEY @"deviceDbEncryptionKey"

//Options for Sync API
#define GET_SYNC_STATS @"getSyncStats"

//Sync Progress Constants
#define PHASE @"phase"
#define STATE @"state"
#define UPLOADED_RECORDS @"totalUploadedRecords"
#define DOWNLOADED_RECORDS @"totalDownloadedRecords"
#define NUMBER_OF_OBJECTS_TO_SYNC @"totalObjectsToSync"
#define TOTAL_RECORDS_TO_UPLOAD @"totalRecordsToUpload"

// Constants for SyncStats
#define NAME @"name"
#define STATS_KEY @"syncStats"
#define START_TIME @"startTime"
#define BATCH_NUMBER @"batchNumber"
#define UPLOAD_STATS @"uploadStats"
#define DOWNLOAD_STATS @"downloadStats"
#define NUMBER_OF_RECORDS @"numberOfRecords"
#define SYNC_ELAPSED_TIME @"syncElapsedTime"
#define REQUEST_CREATION_TIME @"requestCreationTime"
#define NETWORK_DURATION_TIME @"networkDurationTime"
#define RESPONSE_PARSING_TIME @"responseParsingTime"
#define DATA_PERSISTANCE_TIME @"dataPersistanceTime"
#define TOTAL_RECORDS_SYNCED @"numberOfRecordsSynced"
#define TOTAL_UPLOADED_RECORDS @"totalUploadedRecords"
#define TOTAL_DOWNLOADED_RECORDS @"totalDownloadedRecords"

//Constants for CRUD
#define ORDER_BY_ASCENDING @"ASC"
#define ORDER_BY_DESCENDING @"DESC"
#define CRUD_OPTION_ORDERBY_MAP @"orderByMap"
#define CRUD_OPTION_PRIMARY_KEYS @"primaryKeys"
#define CRUD_OPTION_LIKE_CONDITION  @"likeCondition"
#define CRUD_OPTION_WHERE_CONDITION @"whereCondition"
#define CRUD_OPTION_PROJECTION_COLUMNS @"projectionColumns"
#define CRUD_OPTION_WHERE_CONDITION_AS_A_STRING @"whereConditionAsAString"

