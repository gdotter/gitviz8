//
//  KSNetTaskInfo.h
//  KonySyncV2
//
//  Created by Girish Lingarajappa Haniyamballi on 02/12/16.
//  Copyright © 2016 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSNetConstants.h"

/**
 KSNetTaskInfo provides basic info about the service task
 */
@interface KSNetTaskInfo : NSObject

@property(nonatomic, strong) NSString *taskIdentifier;

@property(nonatomic, assign) KSNetServiceAllowableCertificates allowableCertificates;
/**
 Holds the response data received from server.
 */
@property(nonatomic, strong) NSMutableData *responseData;
/**
 Holds the response status code from server.
 */
@property(nonatomic, strong) NSHTTPURLResponse *response;
/**
 Completion handler to be called on task completion.
 */
@property(nonatomic, strong) KSNetworkCompletionHandler completionHandler;

/**
 Appends the received data to existing data.

 @param data data to be appended
 */
- (void)appendResponseData:(NSData *)data;
/**
 Sets Status code received from server.
 
 @param responseStatusCode to set Status code
 */
- (void)setResponse:(NSHTTPURLResponse *)response;

/**
 Initialised the responseData with contents of given file.

 @param location location of file.
 */
- (void)setDataWithLocation:(NSURL *)location;
@end
