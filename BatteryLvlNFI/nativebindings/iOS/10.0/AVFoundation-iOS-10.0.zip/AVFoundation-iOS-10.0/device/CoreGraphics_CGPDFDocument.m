#import <objc/runtime.h>
#import "allincludes.h"
#import "ClassExtension.h"
#import "PointerSupport.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
	context[@"CGPDFDocumentIsUnlocked"] = ^_Bool(id arg0) {
		return CGPDFDocumentIsUnlocked(arg0);
	};
	context[@"CGPDFDocumentCreateWithURL"] = ^id(id arg0) {
		return CGPDFDocumentCreateWithURL(arg0);
	};
	context[@"CGPDFDocumentGetTypeID"] = ^CFTypeID() {
		return CGPDFDocumentGetTypeID();
	};
	context[@"CGPDFDocumentAllowsPrinting"] = ^_Bool(id arg0) {
		return CGPDFDocumentAllowsPrinting(arg0);
	};
	context[@"CGPDFDocumentGetInfo"] = ^id(id arg0) {
		return CGPDFDocumentGetInfo(arg0);
	};
	context[@"CGPDFDocumentAllowsCopying"] = ^_Bool(id arg0) {
		return CGPDFDocumentAllowsCopying(arg0);
	};
	context[@"CGPDFDocumentGetNumberOfPages"] = ^size_t(id arg0) {
		return CGPDFDocumentGetNumberOfPages(arg0);
	};
	context[@"CGPDFDocumentRetain"] = ^id(id arg0) {
		return CGPDFDocumentRetain(arg0);
	};
	context[@"CGPDFDocumentCreateWithProvider"] = ^id(id arg0) {
		return CGPDFDocumentCreateWithProvider(arg0);
	};
	context[@"CGPDFDocumentGetID"] = ^id(id arg0) {
		return CGPDFDocumentGetID(arg0);
	};
	context[@"CGPDFDocumentIsEncrypted"] = ^_Bool(id arg0) {
		return CGPDFDocumentIsEncrypted(arg0);
	};
	context[@"CGPDFDocumentGetCatalog"] = ^id(id arg0) {
		return CGPDFDocumentGetCatalog(arg0);
	};
	context[@"CGPDFDocumentGetPage"] = ^id(id arg0, size_t arg1) {
		return CGPDFDocumentGetPage(arg0, arg1);
	};
	context[@"CGPDFDocumentRelease"] = ^void(id arg0) {
		CGPDFDocumentRelease(arg0);
	};
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_CoreGraphics_CGPDFDocument_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
