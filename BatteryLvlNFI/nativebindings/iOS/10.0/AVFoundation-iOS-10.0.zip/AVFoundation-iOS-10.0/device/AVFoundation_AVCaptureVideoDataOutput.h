#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_AVFoundation_AVCaptureVideoDataOutput_symbols(JSContext*);
@protocol AVCaptureVideoDataOutputInstanceExports<JSExport>
@property (copy,nonatomic) NSDictionary * videoSettings;
@property (readonly,nonatomic) NSArray * availableVideoCodecTypes;
@property (readonly,nonatomic) id sampleBufferDelegate;
@property (nonatomic) CMTime minFrameDuration;
@property (nonatomic) BOOL alwaysDiscardsLateVideoFrames;
@property (readonly,nonatomic) NSArray * availableVideoCVPixelFormatTypes;
-(NSDictionary *) recommendedVideoSettingsForAssetWriterWithOutputFileType: (NSString *) outputFileType ;
@end
@protocol AVCaptureVideoDataOutputClassExports<JSExport>
@end
@protocol AVCaptureVideoDataOutputSampleBufferDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) captureOutput: (AVCaptureOutput *) captureOutput didOutputSampleBuffer: (id) sampleBuffer fromConnection: (AVCaptureConnection *) connection ;
-(void) captureOutput: (AVCaptureOutput *) captureOutput didDropSampleBuffer: (id) sampleBuffer fromConnection: (AVCaptureConnection *) connection ;
@end
@protocol AVCaptureVideoDataOutputSampleBufferDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop