if (strcmp(type, @encode(AUParameterAutomationEvent)) == 0) {
		AUParameterAutomationEvent argument;
		[invocation getArgument: &argument atIndex: index];
		return [JSValue valueWithAUParameterAutomationEvent: argument inContext: context];
	} else if (strcmp(type, @encode(AURecordedParameterEvent)) == 0) {
		AURecordedParameterEvent argument;
		[invocation getArgument: &argument atIndex: index];
		return [JSValue valueWithAURecordedParameterEvent: argument inContext: context];
	}