#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_AVFoundation_AVCapturePhotoOutput_symbols(JSContext*);
@protocol AVCaptureResolvedPhotoSettingsInstanceExports<JSExport>
@property (getter=isFlashEnabled,readonly) BOOL flashEnabled;
@property (readonly) CMVideoDimensions photoDimensions;
@property (readonly) CMVideoDimensions previewDimensions;
@property (readonly) CMVideoDimensions rawPhotoDimensions;
@property (readonly) CMVideoDimensions livePhotoMovieDimensions;
@property (readonly) int64_t uniqueID;
@property (getter=isStillImageStabilizationEnabled,readonly) BOOL stillImageStabilizationEnabled;
@end
@protocol AVCaptureResolvedPhotoSettingsClassExports<JSExport>
@end
@protocol AVCapturePhotoSettingsInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) NSArray * availablePreviewPhotoPixelFormatTypes;
@property (getter=isHighResolutionPhotoEnabled,nonatomic) BOOL highResolutionPhotoEnabled;
@property (readonly,copy) NSDictionary * format;
@property (copy,nonatomic) NSURL * livePhotoMovieFileURL;
@property (copy,nonatomic) NSDictionary * previewPhotoFormat;
@property (nonatomic) AVCaptureFlashMode flashMode;
@property (readonly) int64_t uniqueID;
@property (getter=isAutoStillImageStabilizationEnabled,nonatomic) BOOL autoStillImageStabilizationEnabled;
@property (copy,nonatomic) NSArray * livePhotoMovieMetadata;
@property (readonly) OSType rawPhotoPixelFormatType;
@end
@protocol AVCapturePhotoSettingsClassExports<JSExport, NSCopyingClassExports_>
+(id) photoSettingsWithFormat: (NSDictionary *) format ;
+(id) photoSettingsWithRawPixelFormatType: (OSType) rawPixelFormatType ;
+(id) photoSettingsWithRawPixelFormatType: (OSType) rawPixelFormatType processedFormat: (NSDictionary *) processedFormat ;
+(id) photoSettings;
+(id) photoSettingsFromPhotoSettings: (AVCapturePhotoSettings *) photoSettings ;
@end
@protocol AVCapturePhotoBracketSettingsInstanceExports<JSExport>
@property (readonly,nonatomic) NSArray * bracketedSettings;
@property (getter=isLensStabilizationEnabled,nonatomic) BOOL lensStabilizationEnabled;
@end
@protocol AVCapturePhotoBracketSettingsClassExports<JSExport>
+(id) photoBracketSettingsWithRawPixelFormatType: (OSType) rawPixelFormatType processedFormat: (NSDictionary *) processedFormat bracketedSettings: (NSArray *) bracketedSettings ;
@end
@protocol AVCapturePhotoOutputInstanceExports<JSExport>
@property (readonly,nonatomic) NSArray * availablePhotoCodecTypes;
@property (readonly,nonatomic) NSArray * preparedPhotoSettingsArray;
@property (readonly,nonatomic) BOOL isFlashScene;
@property (getter=isHighResolutionCaptureEnabled,nonatomic) BOOL highResolutionCaptureEnabled;
@property (readonly,nonatomic) BOOL isStillImageStabilizationScene;
@property (copy,nonatomic) AVCapturePhotoSettings * photoSettingsForSceneMonitoring;
@property (getter=isLensStabilizationDuringBracketedCaptureSupported,readonly,nonatomic) BOOL lensStabilizationDuringBracketedCaptureSupported;
@property (getter=isLivePhotoCaptureSupported,readonly,nonatomic) BOOL livePhotoCaptureSupported;
@property (getter=isLivePhotoCaptureEnabled,nonatomic) BOOL livePhotoCaptureEnabled;
@property (readonly,nonatomic) NSArray * availablePhotoPixelFormatTypes;
@property (readonly,nonatomic) NSArray * supportedFlashModes;
@property (readonly,nonatomic) NSArray * availableRawPhotoPixelFormatTypes;
@property (getter=isLivePhotoAutoTrimmingEnabled,nonatomic) BOOL livePhotoAutoTrimmingEnabled;
@property (getter=isStillImageStabilizationSupported,readonly,nonatomic) BOOL stillImageStabilizationSupported;
@property (getter=isLivePhotoCaptureSuspended,nonatomic) BOOL livePhotoCaptureSuspended;
@property (readonly,nonatomic) NSUInteger maxBracketedCapturePhotoCount;
-(void) capturePhotoWithSettings: (AVCapturePhotoSettings *) settings delegate: (id) delegate ;
JSExportAs(setPreparedPhotoSettingsArrayCompletionHandler,
-(void) jssetPreparedPhotoSettingsArray: (NSArray *) preparedPhotoSettingsArray completionHandler: (JSValue *) completionHandler );
@end
@protocol AVCapturePhotoOutputClassExports<JSExport>
+(NSData *) JPEGPhotoDataRepresentationForJPEGSampleBuffer: (id) JPEGSampleBuffer previewPhotoSampleBuffer: (id) previewPhotoSampleBuffer ;
+(NSData *) DNGPhotoDataRepresentationForRawSampleBuffer: (id) rawSampleBuffer previewPhotoSampleBuffer: (id) previewPhotoSampleBuffer ;
@end
@protocol AVCapturePhotoCaptureDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) captureOutput: (AVCapturePhotoOutput *) captureOutput didFinishCaptureForResolvedSettings: (AVCaptureResolvedPhotoSettings *) resolvedSettings error: (NSError *) error ;
-(void) captureOutput: (AVCapturePhotoOutput *) captureOutput willCapturePhotoForResolvedSettings: (AVCaptureResolvedPhotoSettings *) resolvedSettings ;
-(void) captureOutput: (AVCapturePhotoOutput *) captureOutput didCapturePhotoForResolvedSettings: (AVCaptureResolvedPhotoSettings *) resolvedSettings ;
-(void) captureOutput: (AVCapturePhotoOutput *) captureOutput didFinishProcessingPhotoSampleBuffer: (id) photoSampleBuffer previewPhotoSampleBuffer: (id) previewPhotoSampleBuffer resolvedSettings: (AVCaptureResolvedPhotoSettings *) resolvedSettings bracketSettings: (AVCaptureBracketedStillImageSettings *) bracketSettings error: (NSError *) error ;
-(void) captureOutput: (AVCapturePhotoOutput *) captureOutput didFinishProcessingRawPhotoSampleBuffer: (id) rawSampleBuffer previewPhotoSampleBuffer: (id) previewPhotoSampleBuffer resolvedSettings: (AVCaptureResolvedPhotoSettings *) resolvedSettings bracketSettings: (AVCaptureBracketedStillImageSettings *) bracketSettings error: (NSError *) error ;
-(void) captureOutput: (AVCapturePhotoOutput *) captureOutput didFinishRecordingLivePhotoMovieForEventualFileAtURL: (NSURL *) outputFileURL resolvedSettings: (AVCaptureResolvedPhotoSettings *) resolvedSettings ;
-(void) captureOutput: (AVCapturePhotoOutput *) captureOutput willBeginCaptureForResolvedSettings: (AVCaptureResolvedPhotoSettings *) resolvedSettings ;
-(void) captureOutput: (AVCapturePhotoOutput *) captureOutput didFinishProcessingLivePhotoToMovieFileAtURL: (NSURL *) outputFileURL duration: (CMTime) duration photoDisplayTime: (CMTime) photoDisplayTime resolvedSettings: (AVCaptureResolvedPhotoSettings *) resolvedSettings error: (NSError *) error ;
@end
@protocol AVCapturePhotoCaptureDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop