#import <objc/runtime.h>
#import "allincludes.h"
#import "ClassExtension.h"
#import "PointerSupport.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
	context[@"CGColorConverterRelease"] = ^void(id arg0) {
		CGColorConverterRelease(arg0);
	};
	context[@"CGColorConverterGetTypeID"] = ^CFTypeID() {
		return CGColorConverterGetTypeID();
	};
}
static void registerEnumConstants(JSContext* context)
{
	context[@"kCGColorConverterTransformFromSpace"] = @0U;
	context[@"kCGColorConverterTransformToSpace"] = @1U;
	context[@"kCGColorConverterTransformApplySpace"] = @2U;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_CoreGraphics_CGColorConverter_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
