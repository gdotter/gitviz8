#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CAEmitterBehavior_symbols(JSContext*);
@protocol CAEmitterBehaviorInstanceExports<JSExport, NSCodingInstanceExports_>
@property (getter=isEnabled) BOOL enabled;
@property (readonly) NSString * type;
@property (copy) NSString * name;
JSExportAs(initWithType,
-(id) jsinitWithType: (NSString *) type );
@end
@protocol CAEmitterBehaviorClassExports<JSExport, NSCodingClassExports_>
+(NSArray *) behaviorTypes;
+(CAEmitterBehavior *) behaviorWithType: (NSString *) type ;
@end
#pragma clang diagnostic pop